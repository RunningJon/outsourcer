DROP FUNCTION IF EXISTS os.fn_jobstop(text,int,int);

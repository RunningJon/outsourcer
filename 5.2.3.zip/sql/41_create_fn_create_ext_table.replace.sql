DROP FUNCTION IF EXISTS os.fn_create_ext_table(integer, character varying);

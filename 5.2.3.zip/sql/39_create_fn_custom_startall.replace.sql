DROP FUNCTION IF EXISTS os.fn_custom_startall(text, integer);
